package application;

import TrafficSim.Simulator;

public class Main {
	public static void main(String[] args) {
		
		Simulator sim = new Simulator();
		try {
			sim.runScenario(sim.getScenarios()[Integer.parseInt(args[0])]);
		} catch (Exception e) {
			sim.runScenario(sim.getScenarios()[0]);
		}
		
		View theView = new View(sim);
        Controller theController = new Controller(theView, sim);
        String[] scenarios = sim.getScenarios();
        for (String s : scenarios) {
			theView.getScenar().addItem(s);
		}
        theView.setVisible(true);            
    }
 
}
